import os

os.environ["PMD_CMD"] = "/opt/pmd-bin/bin/run.sh pmd"
os.environ["APP_SRC_DIR"] = "/usr/local/src"
